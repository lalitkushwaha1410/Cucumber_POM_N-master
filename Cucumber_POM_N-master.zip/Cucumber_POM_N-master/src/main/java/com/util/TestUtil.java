package com.util;

public class TestUtil
{
	static int PAGE_LOAD_TIME_OUT=40;
	static int IMPLICIT_WAIT=30;

}
